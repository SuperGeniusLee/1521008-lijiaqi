# coding=utf-8
from setuptools import setup, find_packages

setup(
name = '1521008lijiaqi',
version = '0.1',
packages = find_packages(),
py_modules=['判断是否为素数','统计字符数量']
)
