from setuptools import setup, find_packages
setup(
    name='myapp',        
    version='1.0',
    packages = find_packages(),
    py_modules=['1520932鲍昌平 素数','1520932鲍昌平 统计']
)
